const socket = io.connect();

const input = document.getElementById("inp")

console.log(input)

input?.addEventListener("input", ()=>{
    console.log("capturing input event")
    socket.emit("mensajeEnviado", input.value )
})

socket.on("mensajesRecibidos", mensajes =>{
    document.querySelector("p").innerText = mensajes
})


