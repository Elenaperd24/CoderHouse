const express = require("express")
const { Server: HttpServer } = require("http")
const { Server: IOServer } = require("socket.io")

const app = express()
const httpServer = new HttpServer(app)
const io = new IOServer(httpServer)

app.use(express.static("public"))

io.on("connection", socket =>{
    console.log("Nuevo cliente conectado")

    socket.on("mensajeEnviado",  mensajes =>{
        console.log(mensajes)
        io.sockets.emit("mensajesRecibidos", mensajes )
    })

})

const connectedServer = httpServer.listen(8080, ()=>{
    console.log("Servidor http con web sockets listo")
})

connectedServer.on("error", error => console.log)






